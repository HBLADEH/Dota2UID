"""Install the GsCore discovery bridge without importing or restarting GsCore."""

import argparse
import os
from importlib.resources import files
from pathlib import Path

from .config import ensure_config


def install_bridge(host_root: Path, *, token: str = "") -> tuple[Path, Path]:
    root = host_root.resolve()
    if not (root / "gsuid_core" / "server.py").is_file():
        raise ValueError("Expected a GsCore checkout")
    plugins = root / "gsuid_core" / "plugins"
    destination = plugins / "Dota2UID"
    config_dir = root / "data" / "Dota2UID"
    if not destination.resolve().is_relative_to(root) or not config_dir.resolve().is_relative_to(
        root
    ):
        raise ValueError("Dota2UID installation path escapes the host checkout")
    entry = destination / "__init__.py"
    helper = destination / "_dota2forge_config.py"
    source = files("Dota2UID").joinpath("host_entry.py.template").read_text(encoding="utf-8")
    helper_source = (
        files("Dota2UID").joinpath("host_config.py.template").read_text(encoding="utf-8")
    )
    if (entry.exists() and entry.read_text(encoding="utf-8") != source) or (
        helper.exists() and helper.read_text(encoding="utf-8") != helper_source
    ):
        raise ValueError("Existing bridge differs; stop the plugin before replacing it manually")
    destination.mkdir(parents=True, exist_ok=True)
    config_dir.mkdir(parents=True, exist_ok=True)
    config = config_dir / "config.toml"
    ensure_config(config, token=token)
    if not entry.exists():
        entry.write_text(source, encoding="utf-8")
    if not helper.exists():
        helper.write_text(helper_source, encoding="utf-8")
    return entry, config


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--host-root", type=Path, required=True)
    parser.add_argument("--token-from-env", action="store_true")
    args = parser.parse_args()
    token = os.environ.get("STRATZ_TOKEN", "") if args.token_from_env else ""
    try:
        install_bridge(args.host_root, token=token)
    except (ValueError, OSError):
        print("Dota2UID installation failed; verify paths and existing bridge.")
        return 1
    print("Dota2UID bridge installed. Configure Dota2UID in GsCore plugin settings after loading.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
